"use client";
import { Printer } from "lucide-react";
import { Button } from "../Button";
import { Card } from "../Card";
import { Separator } from "../Separator";
import { toast } from "react-hot-toast";

export default function OrderIntakeForm({ formData, setFormData }: any) {
  const checklistItems = [
    "No ink smudges",
    "Proper color tones",
    "Alignment and margins verified",
    "Correct paper used",
    "Accurate size dimensions",
    "Clean finish",
    "No streaks or ghosting",
    "Text readability verified",
    "Trim/cut precision checked",
    "Color consistency across pages",
  ];

  const qaChecklist = formData.qaChecklist || {};
  const allChecked = checklistItems.every((item) => qaChecklist[item]);

  function handleMarkPrinted() {
    setFormData({ ...formData, printStatus: "Printed" });
  }

  function handleToggleAllChecklist() {
    const newChecklistState = checklistItems.reduce((acc, item) => {
      acc[item] = !allChecked;
      return acc;
    }, {} as { [key: string]: boolean });

    setFormData({
      ...formData,
      qaChecklist: newChecklistState,
    });
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 items-stretch w-full px-4 py-6">
      {/* Left Card – Print Job Assignment */}
      <div className="w-full lg:w-1/2">
        <Card className="h-full bg-white shadow-md rounded-xl p-6 md:p-8 flex flex-col justify-between">
          <div className="space-y-6">
            <h2 className="text-xl font-bold text-gray-900">Print Job Assignment</h2>
            <Separator />

            <div className="flex flex-col">
              <label className="text-sm font-medium text-gray-700 mb-1">Assigned Machine/Operator</label>
              <input
                type="text"
                value={formData.printOperator || ""}
                onChange={(e) => setFormData({ ...formData, printOperator: e.target.value })}
                className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-sm font-medium text-gray-700 mb-1">Printing Time (hrs)</label>
              <input
                type="number"
                value={formData.printTime || ""}
                onChange={(e) =>
                  setFormData({ ...formData, printTime: parseFloat(e.target.value) || 0 })
                }
                className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-sm font-medium text-gray-700 mb-1">Batch Information</label>
              <input
                type="text"
                value={formData.batchInfo || ""}
                onChange={(e) => setFormData({ ...formData, batchInfo: e.target.value })}
                className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
              />
            </div>

            <div className="flex flex-col">
              <label className="text-sm font-medium text-gray-700 mb-1">Print Status</label>
              <select
                value={formData.printStatus || "Sent to Printing"}
                onChange={(e) => setFormData({ ...formData, printStatus: e.target.value })}
                className="w-full border border-gray-300 rounded px-3 py-2 bg-white text-black focus:outline-none focus:ring-2 focus:ring-black"
              >
                <option>Sent to Printing</option>
                <option>Printed</option>
              </select>
            </div>

            <p className="text-sm text-black">Estimated Print Time Remaining: 45m</p>
          </div>

          <div className="pt-6 grid grid-cols-2 gap-4">
            <button
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded shadow transition duration-200"
              onClick={() => {
                handleMarkPrinted();
                toast.success("Marked as Printed");
              }}
            >
              Mark as Printed
            </button>

            <button
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded shadow transition duration-200"
              onClick={() => {
                toast.success("Design Assignment section saved!");
                console.log("Saved Data:", formData);
              }}
            >
              Save
            </button>
          </div>
        </Card>
      </div>

      {/* Right Card – QA Checklist */}
      <div className="w-full lg:w-1/2">
        <Card className="h-full bg-white shadow-md rounded-xl p-6 flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-semibold">QA Checklist</h3>
            <div className="space-y-3 mt-4">
              {checklistItems.map((item, idx) => (
                <div key={idx} className="flex items-start">
                  <input
                    type="checkbox"
                    className="mr-2 mt-1"
                    checked={formData.qaChecklist?.[item] || false}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        qaChecklist: {
                          ...formData.qaChecklist,
                          [item]: e.target.checked,
                        },
                      })
                    }
                  />
                  <span className="text-sm">{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Check All / Uncheck All Button */}
          <div className="flex justify-center mt-6">
            <button
              onClick={handleToggleAllChecklist}
              className="text-sm bg-gray-100 border border-gray-300 rounded px-4 py-2 hover:bg-gray-200 transition"
            >
              {allChecked ? "Uncheck All" : "Check All"}
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}
