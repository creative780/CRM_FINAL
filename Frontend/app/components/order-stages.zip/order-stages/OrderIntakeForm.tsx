"use client";

import { useEffect, useRef, useState } from "react";
import { Card } from "../Card";
import { Separator } from "../Separator";
import { toast } from "react-hot-toast";

const groupedProducts: Record<string, string[]> = {
  A: ["Acrylic Keychain", "Air Freshener"],
  B: ["Brochure", "Business Card"],
  C: ["Canvas Print", "Custom Calendar"],
  D: ["Desk Organizer", "Door Hanger"],
  E: ["Envelope", "Event Pass"],
  F: ["Flyer", "Foam Board"],
  G: ["Greeting Card", "Glass Trophy"],
  H: ["Hand Fan", "Hologram Sticker"],
  I: ["Invitation Card", "ID Badge"],
  J: ["Journal", "Jigsaw Puzzle"],
  K: ["Key Holder", "Kraft Bag"],
  L: ["Label Sticker", "Lanyard"],
  M: ["Mug", "Mouse Pad"],
  N: ["Notebook", "Name Badge"],
  O: ["Office Stamp", "Outdoor Banner"],
  P: ["Pen", "Poster"],
  Q: ["Quote Card", "Quick Guide"],
  R: ["Rollup Banner", "Receipt Book"],
  S: ["Sticker", "Standee"],
  T: ["T-Shirt", "Tent Card"],
  U: ["Umbrella", "USB Drive"],
  V: ["Voucher", "Vinyl Print"],
  W: ["Wall Clock", "Water Bottle"],
  X: ["X-Banner", "X-Ray Folder"],
  Y: ["Yoga Mat", "Yard Sign"],
  Z: ["Zipper Pouch", "Z-Fold Brochure"],
};

export default function OrderIntakeForm({ formData, setFormData }: any) {
  const orderIntakeFiles = formData.orderIntakeFiles || [];
  const productDropdownRef = useRef<HTMLDivElement>(null);
  const [searchText, setSearchText] = useState("");
  const [customProductName, setCustomProductName] = useState("");
  const [customProductQty, setCustomProductQty] = useState(1);
  const [addingCustomProduct, setAddingCustomProduct] = useState(false);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        productDropdownRef.current &&
        !productDropdownRef.current.contains(event.target as Node)
      ) {
        setFormData((prev: any) => ({ ...prev, showProductDropdown: false }));
        setAddingCustomProduct(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [setFormData]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    const newFiles = selectedFiles.filter(
      (file) =>
        !orderIntakeFiles.some(
          (existing: File) =>
            existing.name === file.name && existing.size === file.size
        )
    );

    setFormData({
      ...formData,
      orderIntakeFiles: [...orderIntakeFiles, ...newFiles],
    });

    e.target.value = "";
  };

  const handleFileRemove = (index: number) => {
    const updatedFiles = orderIntakeFiles.filter((_, i) => i !== index);
    setFormData({
      ...formData,
      orderIntakeFiles: updatedFiles,
    });
  };

  const handleProductToggle = (product: string) => {
    const currentProducts = formData.products || [];
    const isSelected = currentProducts.some((p: any) => p.name === product);
    const updatedProducts = isSelected
      ? currentProducts.filter((p: any) => p.name !== product)
      : [...currentProducts, { name: product, quantity: 1 }];

    setFormData({
      ...formData,
      products: updatedProducts,
    });
    setSearchText("");
  };

  const handleQuantityChange = (product: string, newQty: number) => {
    if (newQty < 1) return;
    setFormData({
      ...formData,
      products: formData.products.map((p: any) =>
        p.name === product ? { ...p, quantity: newQty } : p
      ),
    });
  };
const flatProductList = Object.values(groupedProducts).flat();
  
  const exactMatch = flatProductList.some(
    (p) => p.toLowerCase() === searchText.toLowerCase()
  );

  const filteredProducts = Object.entries(groupedProducts)
    .flatMap(([_, products]) =>
      products.filter((product) =>
        product.toLowerCase().includes(searchText.toLowerCase())
      )
    );

  const showCustomOption = searchText && !exactMatch && !addingCustomProduct;

  return (
    <Card className="animate-fadeInUp text-black bg-white rounded-xl p-6 md:p-8 space-y-6 w-full shadow shadow-gray-200">
      <h2 className="text-xl font-bold text-gray-900">Client Information</h2>
      <Separator />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Client Name */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Client Name</label>
          <input
            type="text"
            value={formData.clientName}
            onChange={(e) => setFormData({ ...formData, clientName: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
          />
        </div>

        {/* Company Name */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Company Name</label>
          <input
            type="text"
            value={formData.companyName}
            onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
          />
        </div>

        {/* Product Selection */}
<div className="flex flex-col relative" ref={productDropdownRef}>
  <label className="text-sm font-medium text-gray-700 mb-1">Product(s)</label>

  {/* Display selected products as tags */}
  <div className="flex flex-wrap gap-2 mb-2">
    {(formData.products || []).map((product: any, idx: number) => (
      <div
        key={product.name}
        className="flex items-center bg-gray-200 rounded-full px-3 py-1 text-sm"
      >
        {product.name} ({product.quantity})
        <button
          onClick={() =>
            setFormData({
              ...formData,
              products: formData.products.filter((_: any, i: number) => i !== idx),
            })
          }
          className="ml-2 text-gray-500 hover:text-black"
        >
          ✕
        </button>
      </div>
    ))}
  </div>

  <input
    type="text"
    placeholder="Type to search..."
    value={searchText}
    onChange={(e) => {
      setSearchText(e.target.value);
      setFormData({ ...formData, showProductDropdown: true });
    }}
    onFocus={() => setFormData({ ...formData, showProductDropdown: true })}
    onKeyDown={(e) => {
      if (e.key === "Backspace" && searchText === "") {
        const current = formData.products || [];
        if (current.length > 0) {
          const updated = current.slice(0, -1);
          setFormData({ ...formData, products: updated });
        }
      }
    }}
    className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
  />

  {/* Dropdown */}
  {formData.showProductDropdown && (
    <div className="absolute top-full left-0 w-full mt-1 z-10 bg-white border border-gray-300 rounded shadow max-h-60 overflow-y-auto">
      {filteredProducts.map((product) => {
        const selected = formData.products?.find((p: any) => p.name === product);
        return (
          <div
            key={product}
            className="flex items-center gap-2 px-4 py-2 hover:bg-gray-100 text-sm"
          >
            <input
              type="checkbox"
              checked={!!selected}
              onChange={() => handleProductToggle(product)}
              className="cursor-pointer"
            />
            <img
              src="https://via.placeholder.com/24"
              alt={product}
              className="w-6 h-6 rounded object-cover"
            />
            <span className="flex-1">{product}</span>
            {selected && (
              <input
                type="number"
                min={1}
                value={selected.quantity}
                onClick={(e) => e.stopPropagation()}
                onChange={(e) =>
                  handleQuantityChange(product, parseInt(e.target.value))
                }
                className="w-16 border px-1 py-0.5 rounded text-sm"
              />
            )}
          </div>
        );
      })}

      {showCustomOption && (
        <div
          onClick={() => {
            setCustomProductName(searchText);
            setAddingCustomProduct(true);
          }}
          className="px-4 py-2 text-blue-600 hover:bg-gray-100 text-sm cursor-pointer border-t border-gray-100"
        >
          ➕ Add "{searchText}" as a custom product
        </div>
      )}

      {addingCustomProduct && (
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 space-y-2 text-sm">
          <div className="flex items-center gap-2">
            <span className="text-gray-700">Custom Product:</span>
            <strong>{customProductName}</strong>
          </div>
          <div className="flex items-center gap-2">
            <label htmlFor="qty">Qty:</label>
            <input
              id="qty"
              type="number"
              min={1}
              value={customProductQty}
              onChange={(e) => setCustomProductQty(parseInt(e.target.value))}
              className="w-16 border px-2 py-1 rounded text-sm"
            />
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => {
  const currentProducts = formData.products || [];
  const isDuplicate = currentProducts.some((p: any) => p.name === customProductName);

  if (!isDuplicate) {
    setFormData({
      ...formData,
      products: [...currentProducts, { name: customProductName, quantity: customProductQty }],
    });
  }

  setAddingCustomProduct(false);
  setSearchText("");
}}

              className="px-3 py-1 bg-green-600 text-white rounded text-xs"
            >
              Add
            </button>
            <button
              onClick={() => setAddingCustomProduct(false)}
              className="px-3 py-1 bg-[#891F1A] text-white rounded text-xs"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  )}
</div>


        {/* Phone Number */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Phone Number</label>
          <input
            type="tel"
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
          />
        </div>

        {/* Email Address */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
          />
        </div>

        {/* Address */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Address (with Zone)</label>
          <textarea
            value={formData.address}
            onChange={(e) => setFormData({ ...formData, address: e.target.value })}
            rows={2}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black resize-none"
          ></textarea>
        </div>

        {/* Specifications */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Specifications</label>
          <input
            type="text"
            value={formData.specifications}
            onChange={(e) => setFormData({ ...formData, specifications: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 focus:outline-none focus:ring-2 focus:ring-black"
          />
        </div>

        {/* Urgency */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Urgency</label>
          <select
            value={formData.urgency}
            onChange={(e) => setFormData({ ...formData, urgency: e.target.value })}
            className="w-full border border-gray-300 rounded px-3 py-2 bg-white text-black focus:outline-none focus:ring-2 focus:ring-black"
          >
            <option value="">Select Urgency</option>
            <option value="Urgent">Urgent</option>
            <option value="High">High</option>
            <option value="Normal">Normal</option>
            <option value="Low">Low</option>
            <option value="Non-Urgent">Non-Urgent</option>
          </select>
        </div>

        {/* Order ID */}
        <div className="flex flex-col">
          <label className="text-sm font-medium text-gray-700 mb-1">Order ID</label>
          <input
            type="text"
            value={formData.orderId}
            disabled
            className="w-full border border-gray-300 rounded px-3 py-2 bg-gray-100 text-gray-500 cursor-not-allowed"
          />
        </div>
      </div>

      {/* Upload Requirements */}
      <div className="flex flex-col">
        <label className="text-sm font-medium text-gray-700 mb-1">Upload Requirements</label>
        <div className="flex items-center gap-3">
          <label className="cursor-pointer inline-flex items-center px-4 py-2 bg-[#891F1A] text-white text-sm font-medium rounded hover:bg-red-700 transition duration-200 shadow">
            📎 Choose Files
            <input type="file" multiple onChange={handleFileChange} className="hidden" />
          </label>

          {orderIntakeFiles.length > 0 && (
            <span className="text-sm text-gray-600">
              {orderIntakeFiles.length} file(s) selected
            </span>
          )}
        </div>

        {orderIntakeFiles.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
            {orderIntakeFiles.map((file: File, index: number) => {
              const fileExtension = file.name.split(".").pop()?.toLowerCase();
              const isImage = ["jpg", "jpeg", "png", "gif", "bmp"].includes(fileExtension || "");
              const isPdf = fileExtension === "pdf";
              const isDoc = ["doc", "docx"].includes(fileExtension || "");

              const getIcon = () => {
                if (isImage) return "🖼️";
                if (isPdf) return "📄";
                if (isDoc) return "📝";
                return "📁";
              };

              return (
                <div
                  key={index}
                  className="flex items-center justify-between border border-gray-300 rounded px-3 py-2 bg-white shadow-sm hover:shadow-md transition-all"
                >
                  <div className="flex items-center gap-2 overflow-hidden">
                    <span className="text-xl">{getIcon()}</span>
                    <div className="flex flex-col overflow-hidden">
                      <span className="text-sm truncate text-gray-800 font-medium">{file.name}</span>
                      <span className="text-xs text-gray-500">{(file.size / 1024).toFixed(1)} KB</span>
                    </div>
                  </div>
                  <button
                    onClick={() => handleFileRemove(index)}
                    className="ml-3 text-red-500 hover:text-red-700 text-sm font-bold transition duration-200"
                    title="Remove"
                  >
                    ✕
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Order Status */}
      <div className="flex flex-col">
        <label className="text-sm font-medium text-gray-700 mb-1">Order Status</label>
        <select
          value={formData.status}
          onChange={(e) => setFormData({ ...formData, status: e.target.value })}
          className="w-full border border-gray-300 rounded px-3 py-2 bg-white text-black focus:outline-none focus:ring-2 focus:ring-black"
        >
          <option>New</option>
          <option>Under Quotation</option>
          <option>Quoted</option>
          <option>Accepted</option>
        </select>
      </div>

      {/* Save Button */}
      <div className="flex justify-end">
        <button
          onClick={() => toast.success("Client Information saved!!")}
          className="bg-[#891F1A] hover:bg-red-700 text-white font-medium px-6 py-2 rounded shadow transition duration-200"
        >
          Save
        </button>
      </div>
    </Card>
  );
}
